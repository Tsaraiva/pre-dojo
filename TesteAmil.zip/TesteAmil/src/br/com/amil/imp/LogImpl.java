package br.com.amil.imp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import br.com.amil.controller.Log;
import br.com.amil.model.Ranking;

public class LogImpl implements Log {

	@Override
	public StringBuilder load(String file) {

		File arquivo = new File(file);
		StringBuilder conteudo = new StringBuilder();
		BufferedReader reader;

		try {
			reader = new BufferedReader(new FileReader(arquivo));
			String text = "";
			while ((text = reader.readLine()) != null) {
				conteudo.append(text).append(System.getProperty("line.separator"));
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.getMessage();
			System.out.println("Arquivo n�o encontrado!");
		} catch (IOException e) {
			System.out.println("Falha ao tentar ler arquivo! " + e.getMessage());
		}
		return conteudo;
	}
		
	@Override
	public void print(HashMap<String, Ranking> saida) {
		for (Map.Entry<String, Ranking> part : saida.entrySet()) {
		    System.out.println("Partida - " + part.getKey());
		    System.out.println("Total de Assassinatos - " + part.getValue().getQtdeDeath());
		    System.out.println("Total de Mortes - " + part.getValue().getQtdeKills());
		    if (!part.getValue().getKill().containsKey(Collections.max(part.getValue().getDeath().entrySet(), Map.Entry.comparingByValue()).getKey())) {
		    	System.out.println("Vencedor - " + Collections.max(part.getValue().getDeath().entrySet(), Map.Entry.comparingByValue()).getKey() + " com " + Collections.max(part.getValue().getDeath().entrySet(), Map.Entry.comparingByValue()).getValue() + " assassinatos - award");
		    }
		    else {
		    	System.out.println("Vencedor - " + Collections.max(part.getValue().getDeath().entrySet(), Map.Entry.comparingByValue()).getKey() + " com " + Collections.max(part.getValue().getDeath().entrySet(), Map.Entry.comparingByValue()).getValue() + " assassinatos");
		    }
		    System.out.println("Armamento preferido - " + Collections.max(part.getValue().getDonoWeapon().get("Josue").entrySet(), Map.Entry.comparingByValue()).getKey() + " - " + Collections.max(part.getValue().getDonoWeapon().get("Josue").entrySet(), Map.Entry.comparingByValue()).getValue() + "x");
		    System.out.println("");
		    
		    for (Map.Entry<String,Integer> jogadores : part.getValue().getKill().entrySet()) {
		    	System.out.println("Jogador - " + jogadores.getKey() + " - teve " + jogadores.getValue() + " mortes");
		    }
		    
		    System.out.println("");
		    
		    for (Map.Entry<String,Integer> jogadores : part.getValue().getDeath().entrySet()) {
	    		System.out.println("Jogador - " + jogadores.getKey() + " - cometeu " + jogadores.getValue() + " assassinatos");
		    }
		    System.out.println("");
		}
	}
}
