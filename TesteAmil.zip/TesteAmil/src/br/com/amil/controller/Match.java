package br.com.amil.controller;

import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.amil.model.Ranking;
import br.com.amil.util.Constants;

public class Match {
	
HashMap<String, Ranking> partida = new HashMap<String, Ranking>();
	
	String partidaIniciada = "";
	
	public HashMap<String, Ranking> analisaLog (StringBuilder log)
	{			
		Scanner scan = new Scanner(log.toString()); 
		while (scan.hasNextLine()) {
			analisaLinha(scan.nextLine());
		}
		scan.close();
		return partida;
	}
	
	private void analisaLinha(String linha)
	{
		if (retornaPartida(linha,Constants.START) != null) {
			partidaIniciada = retornaPartida(linha,Constants.START);
			partida.put(partidaIniciada, new Ranking());
		}
		
		if (retornaJogador(linha, Constants.KILLED) != null && !linha.contains(Constants.World)) {
			String jogador = retornaJogador(linha, Constants.KILLED);
			String assassino = retornaAssasino(linha, Constants.KILLED);
			Ranking bim = partida.get(partidaIniciada);
			if (bim.getKill().containsKey(jogador)) {
				int mortes = bim.getKill().get(jogador);
				bim.getKill().put(jogador, mortes+1);
			}
			else {
				bim.getKill().put(jogador, 1);
			}
			
			if (bim.getDeath().containsKey(assassino)) {
				int assassinatos = bim.getDeath().get(assassino);
				bim.getDeath().put(assassino, assassinatos+1);
			}
			else {
				bim.getDeath().put(assassino, 1);
			}
			
			bim.setQtdeKills(bim.getQtdeKills()+1);
			bim.setQtdeDeath(bim.getQtdeDeath()+1);
			partida.put(partidaIniciada, bim);
			
			String armamento = retornaArmamento(linha, Constants.WEAPON);
			if (armamento != null) {
				if (bim.getDonoWeapon().containsKey(assassino)) {
					if (bim.getDonoWeapon().get(assassino).containsKey(armamento)) {
						int qtd = bim.getDonoWeapon().get(assassino).get(armamento);
						bim.getDonoWeapon().get(assassino).put(armamento, qtd+1);
					}
					else {
						bim.getDonoWeapon().get(assassino).put(armamento, 1);
					}
				}
				else {
					HashMap<String, Integer> weapon = new HashMap<String, Integer>();
					weapon.put(armamento, 1);
					bim.getDonoWeapon().put(assassino, weapon);
				}	
				partida.put(partidaIniciada, bim);
			}
		}
		else
		{
			if (retornaJogador(linha, Constants.KILLED_WORLD) != null) {
				String jogador = retornaJogador(linha,Constants.KILLED_WORLD);
				//String assassino = retornaAssasino(linha, Constants.KILLED);
				Ranking bim = partida.get(partidaIniciada);
				if (bim.getKill().containsKey(jogador)) {
					int mortes = bim.getKill().get(jogador);
					bim.getKill().put(jogador, mortes+1);
				}
				else {
					bim.getKill().put(jogador, 1);
				}
				
				bim.setQtdeKills(bim.getQtdeKills()+1);
				partida.put(partidaIniciada, bim);
			}
		}
		
		if (retornaPartida(linha,Constants.END) != null) {
			partidaIniciada = "";
		}
	}
	
	public String retornaPartida(String texto, Pattern pattern) {
		Matcher matcher = pattern.matcher(texto);
		if (matcher.matches() && matcher.groupCount() == 1) {
			return matcher.group(1);
		} else {
			return null;
		}
	}
	
	public String retornaJogador(String texto, Pattern pattern) {
		Matcher matcher = pattern.matcher(texto);
		if (matcher.matches() && matcher.groupCount() == 2) {
			return matcher.group(2);
		} else {
			return null;
		}
	}
	
	public String retornaAssasino(String texto, Pattern pattern) {
		Matcher matcher = pattern.matcher(texto);
		if (matcher.matches() && matcher.groupCount() == 2) {
			return matcher.group(1);
		} else {
			return null;
		}
	}
	
	public String retornaArmamento(String texto, Pattern pattern) {
		Matcher matcher = pattern.matcher(texto);
		if (matcher.matches() && matcher.groupCount() == 4) {
			return matcher.group(4);
		} else {
			return null;
		}
	}
}
