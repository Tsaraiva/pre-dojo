package br.com.amil.model;

import java.util.HashMap;

public class Ranking {

	private int qtdeKills;
	private int qtdeDeath;
	private HashMap<String, Integer> kill = new HashMap<String, Integer>();
	private HashMap<String, Integer> death = new HashMap<String, Integer>();
	private HashMap<String, Integer> weapon = new HashMap<String, Integer>();
	private HashMap<String, HashMap<String, Integer>> donoWeapon = new HashMap<String, HashMap<String, Integer>>();
	
	public int getQtdeKills() {
		return qtdeKills;
	}

	public void setQtdeKills(int qtdeKills) {
		this.qtdeKills = qtdeKills;
	}
	
	public int getQtdeDeath() {
		return qtdeDeath;
	}

	public void setQtdeDeath(int qtdeDeaths) {
		this.qtdeDeath = qtdeDeaths;
	}

	public HashMap<String, Integer> getKill() {
		return kill;
	}

	public void setKill(HashMap<String, Integer> kill) {
		this.kill = kill;
	}

	public HashMap<String, Integer> getDeath() {
		return death;
	}

	public void setDeath(HashMap<String, Integer> death) {
		this.death = death;
	}
	
	public HashMap<String, Integer> getWeapon() {
		return weapon;
	}

	public void setWeapon(HashMap<String, Integer> weapon) {
		this.weapon = weapon;
	}
	
	public HashMap<String, HashMap<String, Integer>> getDonoWeapon() {
		return donoWeapon;
	}

	public void setDonoWeapon(HashMap<String, HashMap<String, Integer>> donoWeapon) {
		this.donoWeapon = donoWeapon;
	}
}